(* Created with the Wolfram Language : www.wolfram.com *)
{-\[ScriptCapitalO]ker1[\[Delta]] + \[ScriptCapitalO]ker1[\[Theta]] == 0}
