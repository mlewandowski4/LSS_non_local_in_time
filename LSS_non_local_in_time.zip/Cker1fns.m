(* Created with the Wolfram Language : www.wolfram.com *)
{1, 1}
