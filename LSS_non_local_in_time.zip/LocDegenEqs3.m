(* Created with the Wolfram Language : www.wolfram.com *)
{(10*\[ScriptCapitalO]ker3[r2])/21 + (8*\[ScriptCapitalO]ker3[r3])/63 - 
   (16*\[ScriptCapitalO]ker3[rp])/21 - \[ScriptCapitalO]ker3[\[Delta]] + 
   (4*\[ScriptCapitalO]ker3[r2*\[Delta]])/147 + 
   (2*\[ScriptCapitalO]ker3[\[Delta]^2])/7 - 
   (68*\[ScriptCapitalO]ker3[\[Delta]^3])/441 + \[ScriptCapitalO]ker3[
    \[Theta]] == 0, (-4*\[ScriptCapitalO]ker3[r2*\[Delta]])/7 - 
   \[ScriptCapitalO]ker3[\[Delta]^2] + (4*\[ScriptCapitalO]ker3[\[Delta]^3])/
    7 + \[ScriptCapitalO]ker3[\[Theta]^2] == 0, 
 (-2*\[ScriptCapitalO]ker3[r2*\[Delta]])/7 - \[ScriptCapitalO]ker3[
    \[Delta]^2] + (2*\[ScriptCapitalO]ker3[\[Delta]^3])/7 + 
   \[ScriptCapitalO]ker3[\[Delta]*\[Theta]] == 0, 
 \[ScriptCapitalO]ker3[p2] + \[ScriptCapitalO]ker3[r2] - 
   2*\[ScriptCapitalO]ker3[rp] == 0, 
 -\[ScriptCapitalO]ker3[\[Delta]^3] + \[ScriptCapitalO]ker3[\[Theta]^3] == 0, 
 -\[ScriptCapitalO]ker3[\[Delta]^3] + \[ScriptCapitalO]ker3[
    \[Delta]*\[Theta]^2] == 0, -\[ScriptCapitalO]ker3[\[Delta]^3] + 
   \[ScriptCapitalO]ker3[\[Delta]^2*\[Theta]] == 0, 
 -\[ScriptCapitalO]ker3[r2*\[Delta]] + \[ScriptCapitalO]ker3[p2*\[Theta]] == 
  0, \[ScriptCapitalO]ker3[p2*\[Delta]] - \[ScriptCapitalO]ker3[
    r2*\[Delta]] == 0, -\[ScriptCapitalO]ker3[r2*\[Delta]] + 
   \[ScriptCapitalO]ker3[rp*\[Theta]] == 0, 
 -\[ScriptCapitalO]ker3[r2*\[Delta]] + \[ScriptCapitalO]ker3[rp*\[Delta]] == 
  0, -\[ScriptCapitalO]ker3[r2*\[Delta]] + \[ScriptCapitalO]ker3[
    r2*\[Theta]] == 0, \[ScriptCapitalO]ker3[p3] - 
   \[ScriptCapitalO]ker3[r3] == 0, 
 -\[ScriptCapitalO]ker3[r3] + \[ScriptCapitalO]ker3[rp2] == 0, 
 \[ScriptCapitalO]ker3[r2p] - \[ScriptCapitalO]ker3[r3] == 0}
