(* Created with the Wolfram Language : www.wolfram.com *)
{-Cker3[\[Delta]][1] + Cker3[\[Theta]][1] == 0, 
 (-4*Cker3[r2][1])/7 - (3*Cker3[\[Delta]^2][1])/7 + Cker3[\[Theta]][2] == 0, 
 -1/5*Cker3[r2][2] - (4*Cker3[r3][1])/15 - Cker3[r2*\[Delta]][1]/7 - 
   (4*Cker3[\[Delta]^3][1])/21 + Cker3[\[Theta]][3] == 0, 
 (-2*Cker3[r2][1])/7 + Cker3[\[Delta]][2] - (5*Cker3[\[Delta]^2][1])/7 == 0, 
 -1/15*Cker3[r2][2] - (4*Cker3[r3][1])/45 + Cker3[\[Delta]][3] - 
   Cker3[r2*\[Delta]][1]/3 - (4*Cker3[\[Delta]^3][1])/9 == 0, 
 -Cker3[\[Delta]^2][1] + Cker3[\[Theta]^2][1] == 0, 
 (-8*Cker3[r2*\[Delta]][1])/7 - (6*Cker3[\[Delta]^3][1])/7 + 
   Cker3[\[Theta]^2][2] == 0, 
 -Cker3[\[Delta]^2][1] + Cker3[\[Delta]*\[Theta]][1] == 0, 
 (-6*Cker3[r2*\[Delta]][1])/7 - (8*Cker3[\[Delta]^3][1])/7 + 
   Cker3[\[Delta]*\[Theta]][2] == 0, 
 (-4*Cker3[r2*\[Delta]][1])/7 + Cker3[\[Delta]^2][2] - 
   (10*Cker3[\[Delta]^3][1])/7 == 0, Cker3[p2][1] - Cker3[r2][1] == 0, 
 Cker3[p2][2] - (3*Cker3[r2][2])/5 - (4*Cker3[r3][1])/5 == 0, 
 -Cker3[r2][1] + Cker3[rp][1] == 0, 
 (-4*Cker3[r2][2])/5 - (2*Cker3[r3][1])/5 + Cker3[rp][2] == 0, 
 -Cker3[\[Delta]^3][1] + Cker3[\[Theta]^3][1] == 0, 
 -Cker3[\[Delta]^3][1] + Cker3[\[Delta]*\[Theta]^2][1] == 0, 
 -Cker3[\[Delta]^3][1] + Cker3[\[Delta]^2*\[Theta]][1] == 0, 
 -Cker3[r2*\[Delta]][1] + Cker3[p2*\[Theta]][1] == 0, 
 Cker3[p2*\[Delta]][1] - Cker3[r2*\[Delta]][1] == 0, 
 -Cker3[r2*\[Delta]][1] + Cker3[rp*\[Theta]][1] == 0, 
 -Cker3[r2*\[Delta]][1] + Cker3[rp*\[Delta]][1] == 0, 
 -Cker3[r2*\[Delta]][1] + Cker3[r2*\[Theta]][1] == 0, 
 Cker3[p3][1] - Cker3[r3][1] == 0, -Cker3[r3][1] + Cker3[rp2][1] == 0, 
 Cker3[r2p][1] - Cker3[r3][1] == 0}
