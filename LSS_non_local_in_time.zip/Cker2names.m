(* Created with the Wolfram Language : www.wolfram.com *)
{Cker2[\[Theta]][1], Cker2[\[Theta]][2], Cker2[\[Delta]][1], 
 Cker2[\[Delta]][2], Cker2[\[Theta]^2][1], Cker2[\[Delta]*\[Theta]][1], 
 Cker2[\[Delta]^2][1], Cker2[p2][1], Cker2[rp][1], Cker2[r2][1]}
