(* Created with the Wolfram Language : www.wolfram.com *)
{((dot[k1, k2]*dot[k1, k3])/(2*magM[k1]^2*magM[k2]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k1]^2*magM[k2]^2) - 
    (dot[k1, k3]*G2ker[k1, k2])/(2*(-2*dot[k1, k2] - magM[k1]^2 - 
       magM[k2]^2)) - (dot[k2, k3]*G2ker[k1, k2])/
     (2*(-2*dot[k1, k2] - magM[k1]^2 - magM[k2]^2)))/6 + 
  ((dot[k1, k2]*dot[k2, k3])/(2*magM[k1]^2*magM[k2]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k1]^2*magM[k2]^2) - 
    (dot[k1, k3]*G2ker[k1, k2])/(2*(-2*dot[k1, k2] - magM[k1]^2 - 
       magM[k2]^2)) - (dot[k2, k3]*G2ker[k1, k2])/
     (2*(-2*dot[k1, k2] - magM[k1]^2 - magM[k2]^2)))/6 + 
  ((dot[k1, k2]*dot[k1, k3])/(2*magM[k1]^2*magM[k3]^2) + 
    (dot[k1, k2]*dot[k2, k3])/(2*magM[k1]^2*magM[k3]^2) - 
    (dot[k1, k2]*G2ker[k1, k3])/(2*(-2*dot[k1, k3] - magM[k1]^2 - 
       magM[k3]^2)) - (dot[k2, k3]*G2ker[k1, k3])/
     (2*(-2*dot[k1, k3] - magM[k1]^2 - magM[k3]^2)))/6 + 
  ((dot[k1, k2]*dot[k2, k3])/(2*magM[k1]^2*magM[k3]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k1]^2*magM[k3]^2) - 
    (dot[k1, k2]*G2ker[k1, k3])/(2*(-2*dot[k1, k3] - magM[k1]^2 - 
       magM[k3]^2)) - (dot[k2, k3]*G2ker[k1, k3])/
     (2*(-2*dot[k1, k3] - magM[k1]^2 - magM[k3]^2)))/6 + 
  ((dot[k1, k2]*dot[k1, k3])/(2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k2]*dot[k2, k3])/(2*magM[k2]^2*magM[k3]^2) - 
    (dot[k1, k2]*G2ker[k2, k3])/(2*(-2*dot[k2, k3] - magM[k2]^2 - 
       magM[k3]^2)) - (dot[k1, k3]*G2ker[k2, k3])/
     (2*(-2*dot[k2, k3] - magM[k2]^2 - magM[k3]^2)))/6 + 
  ((dot[k1, k2]*dot[k1, k3])/(2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k2]^2*magM[k3]^2) - 
    (dot[k1, k2]*G2ker[k2, k3])/(2*(-2*dot[k2, k3] - magM[k2]^2 - 
       magM[k3]^2)) - (dot[k1, k3]*G2ker[k2, k3])/
     (2*(-2*dot[k2, k3] - magM[k2]^2 - magM[k3]^2)))/6, 
 ((dot[k1, k2]*G2ker[k2, k3])/magM[k1]^2 + (dot[k1, k3]*G2ker[k2, k3])/
     magM[k1]^2 - (dot[k1, k2]*dot[k1, k3])/(magM[k1]^2*magM[k2]^2) - 
    (dot[k1, k3]*dot[k2, k3])/(magM[k1]^2*magM[k2]^2))/6 + 
  ((dot[k1, k2]*G2ker[k1, k3])/magM[k2]^2 + (dot[k2, k3]*G2ker[k1, k3])/
     magM[k2]^2 - (dot[k1, k2]*dot[k2, k3])/(magM[k1]^2*magM[k2]^2) - 
    (dot[k1, k3]*dot[k2, k3])/(magM[k1]^2*magM[k2]^2))/6 + 
  ((dot[k1, k2]*G2ker[k2, k3])/magM[k1]^2 + (dot[k1, k3]*G2ker[k2, k3])/
     magM[k1]^2 - (dot[k1, k2]*dot[k1, k3])/(magM[k1]^2*magM[k3]^2) - 
    (dot[k1, k2]*dot[k2, k3])/(magM[k1]^2*magM[k3]^2))/6 + 
  ((dot[k1, k3]*G2ker[k1, k2])/magM[k3]^2 + (dot[k2, k3]*G2ker[k1, k2])/
     magM[k3]^2 - (dot[k1, k2]*dot[k2, k3])/(magM[k1]^2*magM[k3]^2) - 
    (dot[k1, k3]*dot[k2, k3])/(magM[k1]^2*magM[k3]^2))/6 + 
  ((dot[k1, k2]*G2ker[k1, k3])/magM[k2]^2 + (dot[k2, k3]*G2ker[k1, k3])/
     magM[k2]^2 - (dot[k1, k2]*dot[k1, k3])/(magM[k2]^2*magM[k3]^2) - 
    (dot[k1, k2]*dot[k2, k3])/(magM[k2]^2*magM[k3]^2))/6 + 
  ((dot[k1, k3]*G2ker[k1, k2])/magM[k3]^2 + (dot[k2, k3]*G2ker[k1, k2])/
     magM[k3]^2 - (dot[k1, k2]*dot[k1, k3])/(magM[k2]^2*magM[k3]^2) - 
    (dot[k1, k3]*dot[k2, k3])/(magM[k2]^2*magM[k3]^2))/6, 
 (G3ker[k1, k2, k3] - (dot[k1, k2]*G2ker[k2, k3])/magM[k1]^2 - 
    (dot[k1, k3]*G2ker[k2, k3])/magM[k1]^2 + (dot[k1, k2]*dot[k1, k3])/
     (2*magM[k1]^2*magM[k2]^2) + (dot[k1, k3]*dot[k2, k3])/
     (2*magM[k1]^2*magM[k2]^2) + (dot[k1, k3]*G2ker[k1, k2])/
     (2*(-2*dot[k1, k2] - magM[k1]^2 - magM[k2]^2)) + 
    (dot[k2, k3]*G2ker[k1, k2])/(2*(-2*dot[k1, k2] - magM[k1]^2 - 
       magM[k2]^2)))/6 + (G3ker[k1, k2, k3] - (dot[k1, k2]*G2ker[k1, k3])/
     magM[k2]^2 - (dot[k2, k3]*G2ker[k1, k3])/magM[k2]^2 + 
    (dot[k1, k2]*dot[k2, k3])/(2*magM[k1]^2*magM[k2]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k1]^2*magM[k2]^2) + 
    (dot[k1, k3]*G2ker[k1, k2])/(2*(-2*dot[k1, k2] - magM[k1]^2 - 
       magM[k2]^2)) + (dot[k2, k3]*G2ker[k1, k2])/
     (2*(-2*dot[k1, k2] - magM[k1]^2 - magM[k2]^2)))/6 + 
  (G3ker[k1, k2, k3] - (dot[k1, k2]*G2ker[k2, k3])/magM[k1]^2 - 
    (dot[k1, k3]*G2ker[k2, k3])/magM[k1]^2 + (dot[k1, k2]*dot[k1, k3])/
     (2*magM[k1]^2*magM[k3]^2) + (dot[k1, k2]*dot[k2, k3])/
     (2*magM[k1]^2*magM[k3]^2) + (dot[k1, k2]*G2ker[k1, k3])/
     (2*(-2*dot[k1, k3] - magM[k1]^2 - magM[k3]^2)) + 
    (dot[k2, k3]*G2ker[k1, k3])/(2*(-2*dot[k1, k3] - magM[k1]^2 - 
       magM[k3]^2)))/6 + (G3ker[k1, k2, k3] - (dot[k1, k3]*G2ker[k1, k2])/
     magM[k3]^2 - (dot[k2, k3]*G2ker[k1, k2])/magM[k3]^2 + 
    (dot[k1, k2]*dot[k2, k3])/(2*magM[k1]^2*magM[k3]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k1]^2*magM[k3]^2) + 
    (dot[k1, k2]*G2ker[k1, k3])/(2*(-2*dot[k1, k3] - magM[k1]^2 - 
       magM[k3]^2)) + (dot[k2, k3]*G2ker[k1, k3])/
     (2*(-2*dot[k1, k3] - magM[k1]^2 - magM[k3]^2)))/6 + 
  (G3ker[k1, k2, k3] - (dot[k1, k2]*G2ker[k1, k3])/magM[k2]^2 - 
    (dot[k2, k3]*G2ker[k1, k3])/magM[k2]^2 + (dot[k1, k2]*dot[k1, k3])/
     (2*magM[k2]^2*magM[k3]^2) + (dot[k1, k2]*dot[k2, k3])/
     (2*magM[k2]^2*magM[k3]^2) + (dot[k1, k2]*G2ker[k2, k3])/
     (2*(-2*dot[k2, k3] - magM[k2]^2 - magM[k3]^2)) + 
    (dot[k1, k3]*G2ker[k2, k3])/(2*(-2*dot[k2, k3] - magM[k2]^2 - 
       magM[k3]^2)))/6 + (G3ker[k1, k2, k3] - (dot[k1, k3]*G2ker[k1, k2])/
     magM[k3]^2 - (dot[k2, k3]*G2ker[k1, k2])/magM[k3]^2 + 
    (dot[k1, k2]*dot[k1, k3])/(2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k2]*G2ker[k2, k3])/(2*(-2*dot[k2, k3] - magM[k2]^2 - 
       magM[k3]^2)) + (dot[k1, k3]*G2ker[k2, k3])/
     (2*(-2*dot[k2, k3] - magM[k2]^2 - magM[k3]^2)))/6, 
 ((dot[k1, k2]*dot[k1, k3])/(2*magM[k1]^2*magM[k2]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k1]^2*magM[k2]^2) - 
    (dot[k1, k3]*G2ker[k1, k2])/(2*(-2*dot[k1, k2] - magM[k1]^2 - 
       magM[k2]^2)) - (dot[k2, k3]*G2ker[k1, k2])/
     (2*(-2*dot[k1, k2] - magM[k1]^2 - magM[k2]^2)))/6 + 
  ((dot[k1, k2]*dot[k2, k3])/(2*magM[k1]^2*magM[k2]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k1]^2*magM[k2]^2) - 
    (dot[k1, k3]*G2ker[k1, k2])/(2*(-2*dot[k1, k2] - magM[k1]^2 - 
       magM[k2]^2)) - (dot[k2, k3]*G2ker[k1, k2])/
     (2*(-2*dot[k1, k2] - magM[k1]^2 - magM[k2]^2)))/6 + 
  ((dot[k1, k2]*dot[k1, k3])/(2*magM[k1]^2*magM[k3]^2) + 
    (dot[k1, k2]*dot[k2, k3])/(2*magM[k1]^2*magM[k3]^2) - 
    (dot[k1, k2]*G2ker[k1, k3])/(2*(-2*dot[k1, k3] - magM[k1]^2 - 
       magM[k3]^2)) - (dot[k2, k3]*G2ker[k1, k3])/
     (2*(-2*dot[k1, k3] - magM[k1]^2 - magM[k3]^2)))/6 + 
  ((dot[k1, k2]*dot[k2, k3])/(2*magM[k1]^2*magM[k3]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k1]^2*magM[k3]^2) - 
    (dot[k1, k2]*G2ker[k1, k3])/(2*(-2*dot[k1, k3] - magM[k1]^2 - 
       magM[k3]^2)) - (dot[k2, k3]*G2ker[k1, k3])/
     (2*(-2*dot[k1, k3] - magM[k1]^2 - magM[k3]^2)))/6 + 
  ((dot[k1, k2]*dot[k1, k3])/(2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k2]*dot[k2, k3])/(2*magM[k2]^2*magM[k3]^2) - 
    (dot[k1, k2]*G2ker[k2, k3])/(2*(-2*dot[k2, k3] - magM[k2]^2 - 
       magM[k3]^2)) - (dot[k1, k3]*G2ker[k2, k3])/
     (2*(-2*dot[k2, k3] - magM[k2]^2 - magM[k3]^2)))/6 + 
  ((dot[k1, k2]*dot[k1, k3])/(2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k2]^2*magM[k3]^2) - 
    (dot[k1, k2]*G2ker[k2, k3])/(2*(-2*dot[k2, k3] - magM[k2]^2 - 
       magM[k3]^2)) - (dot[k1, k3]*G2ker[k2, k3])/
     (2*(-2*dot[k2, k3] - magM[k2]^2 - magM[k3]^2)))/6, 
 ((dot[k1, k2]*F2ker[k2, k3])/magM[k1]^2 + (dot[k1, k3]*F2ker[k2, k3])/
     magM[k1]^2 - (dot[k1, k2]*dot[k1, k3])/(magM[k1]^2*magM[k2]^2) - 
    (dot[k1, k3]*dot[k2, k3])/(magM[k1]^2*magM[k2]^2))/6 + 
  ((dot[k1, k2]*F2ker[k1, k3])/magM[k2]^2 + (dot[k2, k3]*F2ker[k1, k3])/
     magM[k2]^2 - (dot[k1, k2]*dot[k2, k3])/(magM[k1]^2*magM[k2]^2) - 
    (dot[k1, k3]*dot[k2, k3])/(magM[k1]^2*magM[k2]^2))/6 + 
  ((dot[k1, k2]*F2ker[k2, k3])/magM[k1]^2 + (dot[k1, k3]*F2ker[k2, k3])/
     magM[k1]^2 - (dot[k1, k2]*dot[k1, k3])/(magM[k1]^2*magM[k3]^2) - 
    (dot[k1, k2]*dot[k2, k3])/(magM[k1]^2*magM[k3]^2))/6 + 
  ((dot[k1, k3]*F2ker[k1, k2])/magM[k3]^2 + (dot[k2, k3]*F2ker[k1, k2])/
     magM[k3]^2 - (dot[k1, k2]*dot[k2, k3])/(magM[k1]^2*magM[k3]^2) - 
    (dot[k1, k3]*dot[k2, k3])/(magM[k1]^2*magM[k3]^2))/6 + 
  ((dot[k1, k2]*F2ker[k1, k3])/magM[k2]^2 + (dot[k2, k3]*F2ker[k1, k3])/
     magM[k2]^2 - (dot[k1, k2]*dot[k1, k3])/(magM[k2]^2*magM[k3]^2) - 
    (dot[k1, k2]*dot[k2, k3])/(magM[k2]^2*magM[k3]^2))/6 + 
  ((dot[k1, k3]*F2ker[k1, k2])/magM[k3]^2 + (dot[k2, k3]*F2ker[k1, k2])/
     magM[k3]^2 - (dot[k1, k2]*dot[k1, k3])/(magM[k2]^2*magM[k3]^2) - 
    (dot[k1, k3]*dot[k2, k3])/(magM[k2]^2*magM[k3]^2))/6, 
 (F3ker[k1, k2, k3] - (dot[k1, k2]*F2ker[k2, k3])/magM[k1]^2 - 
    (dot[k1, k3]*F2ker[k2, k3])/magM[k1]^2 + (dot[k1, k2]*dot[k1, k3])/
     (2*magM[k1]^2*magM[k2]^2) + (dot[k1, k3]*dot[k2, k3])/
     (2*magM[k1]^2*magM[k2]^2) + (dot[k1, k3]*G2ker[k1, k2])/
     (2*(-2*dot[k1, k2] - magM[k1]^2 - magM[k2]^2)) + 
    (dot[k2, k3]*G2ker[k1, k2])/(2*(-2*dot[k1, k2] - magM[k1]^2 - 
       magM[k2]^2)))/6 + (F3ker[k1, k2, k3] - (dot[k1, k2]*F2ker[k1, k3])/
     magM[k2]^2 - (dot[k2, k3]*F2ker[k1, k3])/magM[k2]^2 + 
    (dot[k1, k2]*dot[k2, k3])/(2*magM[k1]^2*magM[k2]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k1]^2*magM[k2]^2) + 
    (dot[k1, k3]*G2ker[k1, k2])/(2*(-2*dot[k1, k2] - magM[k1]^2 - 
       magM[k2]^2)) + (dot[k2, k3]*G2ker[k1, k2])/
     (2*(-2*dot[k1, k2] - magM[k1]^2 - magM[k2]^2)))/6 + 
  (F3ker[k1, k2, k3] - (dot[k1, k2]*F2ker[k2, k3])/magM[k1]^2 - 
    (dot[k1, k3]*F2ker[k2, k3])/magM[k1]^2 + (dot[k1, k2]*dot[k1, k3])/
     (2*magM[k1]^2*magM[k3]^2) + (dot[k1, k2]*dot[k2, k3])/
     (2*magM[k1]^2*magM[k3]^2) + (dot[k1, k2]*G2ker[k1, k3])/
     (2*(-2*dot[k1, k3] - magM[k1]^2 - magM[k3]^2)) + 
    (dot[k2, k3]*G2ker[k1, k3])/(2*(-2*dot[k1, k3] - magM[k1]^2 - 
       magM[k3]^2)))/6 + (F3ker[k1, k2, k3] - (dot[k1, k3]*F2ker[k1, k2])/
     magM[k3]^2 - (dot[k2, k3]*F2ker[k1, k2])/magM[k3]^2 + 
    (dot[k1, k2]*dot[k2, k3])/(2*magM[k1]^2*magM[k3]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k1]^2*magM[k3]^2) + 
    (dot[k1, k2]*G2ker[k1, k3])/(2*(-2*dot[k1, k3] - magM[k1]^2 - 
       magM[k3]^2)) + (dot[k2, k3]*G2ker[k1, k3])/
     (2*(-2*dot[k1, k3] - magM[k1]^2 - magM[k3]^2)))/6 + 
  (F3ker[k1, k2, k3] - (dot[k1, k2]*F2ker[k1, k3])/magM[k2]^2 - 
    (dot[k2, k3]*F2ker[k1, k3])/magM[k2]^2 + (dot[k1, k2]*dot[k1, k3])/
     (2*magM[k2]^2*magM[k3]^2) + (dot[k1, k2]*dot[k2, k3])/
     (2*magM[k2]^2*magM[k3]^2) + (dot[k1, k2]*G2ker[k2, k3])/
     (2*(-2*dot[k2, k3] - magM[k2]^2 - magM[k3]^2)) + 
    (dot[k1, k3]*G2ker[k2, k3])/(2*(-2*dot[k2, k3] - magM[k2]^2 - 
       magM[k3]^2)))/6 + (F3ker[k1, k2, k3] - (dot[k1, k3]*F2ker[k1, k2])/
     magM[k3]^2 - (dot[k2, k3]*F2ker[k1, k2])/magM[k3]^2 + 
    (dot[k1, k2]*dot[k1, k3])/(2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]*dot[k2, k3])/(2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k2]*G2ker[k2, k3])/(2*(-2*dot[k2, k3] - magM[k2]^2 - 
       magM[k3]^2)) + (dot[k1, k3]*G2ker[k2, k3])/
     (2*(-2*dot[k2, k3] - magM[k2]^2 - magM[k3]^2)))/6, 
 (dot[k1, k2]/magM[k1]^2 + dot[k1, k3]/magM[k1]^2)/3 + 
  (dot[k1, k2]/magM[k2]^2 + dot[k2, k3]/magM[k2]^2)/3 + 
  (dot[k1, k3]/magM[k3]^2 + dot[k2, k3]/magM[k3]^2)/3, 
 (2*G2ker[k2, k3] - dot[k1, k2]/magM[k1]^2 - dot[k1, k3]/magM[k1]^2)/3 + 
  (2*G2ker[k1, k3] - dot[k1, k2]/magM[k2]^2 - dot[k2, k3]/magM[k2]^2)/3 + 
  (2*G2ker[k1, k2] - dot[k1, k3]/magM[k3]^2 - dot[k2, k3]/magM[k3]^2)/3, 
 (dot[k1, k2]/magM[k1]^2 + dot[k1, k3]/magM[k1]^2)/3 + 
  (dot[k1, k2]/magM[k2]^2 + dot[k2, k3]/magM[k2]^2)/3 + 
  (dot[k1, k3]/magM[k3]^2 + dot[k2, k3]/magM[k3]^2)/3, 
 (F2ker[k2, k3] + G2ker[k2, k3] - dot[k1, k2]/magM[k1]^2 - 
    dot[k1, k3]/magM[k1]^2)/3 + (F2ker[k1, k3] + G2ker[k1, k3] - 
    dot[k1, k2]/magM[k2]^2 - dot[k2, k3]/magM[k2]^2)/3 + 
  (F2ker[k1, k2] + G2ker[k1, k2] - dot[k1, k3]/magM[k3]^2 - 
    dot[k2, k3]/magM[k3]^2)/3, 
 (dot[k1, k2]/magM[k1]^2 + dot[k1, k3]/magM[k1]^2)/3 + 
  (dot[k1, k2]/magM[k2]^2 + dot[k2, k3]/magM[k2]^2)/3 + 
  (dot[k1, k3]/magM[k3]^2 + dot[k2, k3]/magM[k3]^2)/3, 
 (2*F2ker[k2, k3] - dot[k1, k2]/magM[k1]^2 - dot[k1, k3]/magM[k1]^2)/3 + 
  (2*F2ker[k1, k3] - dot[k1, k2]/magM[k2]^2 - dot[k2, k3]/magM[k2]^2)/3 + 
  (2*F2ker[k1, k2] - dot[k1, k3]/magM[k3]^2 - dot[k2, k3]/magM[k3]^2)/3, 
 ((dot[k1, k2]^2*dot[k1, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k2]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2))/3 + 
  ((dot[k1, k2]*dot[k1, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2))/3 + 
  ((dot[k1, k2]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2))/3, 
 (-((dot[k1, k2]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2)) - 
    (dot[k1, k3]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]^2*G2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (2*dot[k1, k3]*dot[k2, k3]*G2ker[k1, k2])/
     ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2) + 
    (dot[k2, k3]^2*G2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (dot[k1, k2]^2*G2ker[k1, k3])/
     (magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
    (2*dot[k1, k2]*dot[k2, k3]*G2ker[k1, k3])/
     (magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
    (dot[k2, k3]^2*G2ker[k1, k3])/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
       magM[k3]^2)))/3 + 
  (-((dot[k1, k2]*dot[k1, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2)) - 
    (dot[k1, k3]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]^2*G2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (2*dot[k1, k3]*dot[k2, k3]*G2ker[k1, k2])/
     ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2) + 
    (dot[k2, k3]^2*G2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (dot[k1, k2]^2*G2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (2*dot[k1, k2]*dot[k1, k3]*G2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (dot[k1, k3]^2*G2ker[k2, k3])/(magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + 
       magM[k3]^2)))/3 + 
  (-((dot[k1, k2]^2*dot[k1, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2)) - 
    (dot[k1, k2]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k2]^2*G2ker[k1, k3])/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
       magM[k3]^2)) + (2*dot[k1, k2]*dot[k2, k3]*G2ker[k1, k3])/
     (magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
    (dot[k2, k3]^2*G2ker[k1, k3])/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
       magM[k3]^2)) + (dot[k1, k2]^2*G2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (2*dot[k1, k2]*dot[k1, k3]*G2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (dot[k1, k3]^2*G2ker[k2, k3])/(magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + 
       magM[k3]^2)))/3, 
 ((dot[k1, k2]^2*dot[k1, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k2]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2))/3 + 
  ((dot[k1, k2]*dot[k1, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2))/3 + 
  ((dot[k1, k2]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2))/3, 
 (-((dot[k1, k2]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2)) - 
    (dot[k1, k3]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]^2*G2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (2*dot[k1, k3]*dot[k2, k3]*G2ker[k1, k2])/
     ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2) + 
    (dot[k2, k3]^2*G2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (dot[k1, k2]^2*F2ker[k1, k3])/
     (magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
    (2*dot[k1, k2]*dot[k2, k3]*F2ker[k1, k3])/
     (magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
    (dot[k2, k3]^2*F2ker[k1, k3])/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
       magM[k3]^2)))/6 + 
  (-((dot[k1, k2]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2)) - 
    (dot[k1, k3]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]^2*F2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (2*dot[k1, k3]*dot[k2, k3]*F2ker[k1, k2])/
     ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2) + 
    (dot[k2, k3]^2*F2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (dot[k1, k2]^2*G2ker[k1, k3])/
     (magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
    (2*dot[k1, k2]*dot[k2, k3]*G2ker[k1, k3])/
     (magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
    (dot[k2, k3]^2*G2ker[k1, k3])/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
       magM[k3]^2)))/6 + 
  (-((dot[k1, k2]*dot[k1, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2)) - 
    (dot[k1, k3]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]^2*G2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (2*dot[k1, k3]*dot[k2, k3]*G2ker[k1, k2])/
     ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2) + 
    (dot[k2, k3]^2*G2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (dot[k1, k2]^2*F2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (2*dot[k1, k2]*dot[k1, k3]*F2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (dot[k1, k3]^2*F2ker[k2, k3])/(magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + 
       magM[k3]^2)))/6 + 
  (-((dot[k1, k2]^2*dot[k1, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2)) - 
    (dot[k1, k2]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k2]^2*G2ker[k1, k3])/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
       magM[k3]^2)) + (2*dot[k1, k2]*dot[k2, k3]*G2ker[k1, k3])/
     (magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
    (dot[k2, k3]^2*G2ker[k1, k3])/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
       magM[k3]^2)) + (dot[k1, k2]^2*F2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (2*dot[k1, k2]*dot[k1, k3]*F2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (dot[k1, k3]^2*F2ker[k2, k3])/(magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + 
       magM[k3]^2)))/6 + 
  (-((dot[k1, k2]*dot[k1, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2)) - 
    (dot[k1, k3]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]^2*F2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (2*dot[k1, k3]*dot[k2, k3]*F2ker[k1, k2])/
     ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2) + 
    (dot[k2, k3]^2*F2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (dot[k1, k2]^2*G2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (2*dot[k1, k2]*dot[k1, k3]*G2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (dot[k1, k3]^2*G2ker[k2, k3])/(magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + 
       magM[k3]^2)))/6 + 
  (-((dot[k1, k2]^2*dot[k1, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2)) - 
    (dot[k1, k2]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k2]^2*F2ker[k1, k3])/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
       magM[k3]^2)) + (2*dot[k1, k2]*dot[k2, k3]*F2ker[k1, k3])/
     (magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
    (dot[k2, k3]^2*F2ker[k1, k3])/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
       magM[k3]^2)) + (dot[k1, k2]^2*G2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (2*dot[k1, k2]*dot[k1, k3]*G2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (dot[k1, k3]^2*G2ker[k2, k3])/(magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + 
       magM[k3]^2)))/6, 
 ((dot[k1, k2]^2*dot[k1, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k2]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2))/3 + 
  ((dot[k1, k2]*dot[k1, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2))/3 + 
  ((dot[k1, k2]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2))/3, 
 (-((dot[k1, k2]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2)) - 
    (dot[k1, k3]*dot[k2, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]^2*F2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (2*dot[k1, k3]*dot[k2, k3]*F2ker[k1, k2])/
     ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2) + 
    (dot[k2, k3]^2*F2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (dot[k1, k2]^2*F2ker[k1, k3])/
     (magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
    (2*dot[k1, k2]*dot[k2, k3]*F2ker[k1, k3])/
     (magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
    (dot[k2, k3]^2*F2ker[k1, k3])/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
       magM[k3]^2)))/3 + 
  (-((dot[k1, k2]*dot[k1, k3]^2)/(magM[k1]^2*magM[k2]^2*magM[k3]^2)) - 
    (dot[k1, k3]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k3]^2*F2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (2*dot[k1, k3]*dot[k2, k3]*F2ker[k1, k2])/
     ((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*magM[k3]^2) + 
    (dot[k2, k3]^2*F2ker[k1, k2])/((2*dot[k1, k2] + magM[k1]^2 + magM[k2]^2)*
      magM[k3]^2) + (dot[k1, k2]^2*F2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (2*dot[k1, k2]*dot[k1, k3]*F2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (dot[k1, k3]^2*F2ker[k2, k3])/(magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + 
       magM[k3]^2)))/3 + 
  (-((dot[k1, k2]^2*dot[k1, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2)) - 
    (dot[k1, k2]^2*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2) + 
    (dot[k1, k2]^2*F2ker[k1, k3])/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
       magM[k3]^2)) + (2*dot[k1, k2]*dot[k2, k3]*F2ker[k1, k3])/
     (magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + magM[k3]^2)) + 
    (dot[k2, k3]^2*F2ker[k1, k3])/(magM[k2]^2*(2*dot[k1, k3] + magM[k1]^2 + 
       magM[k3]^2)) + (dot[k1, k2]^2*F2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (2*dot[k1, k2]*dot[k1, k3]*F2ker[k2, k3])/
     (magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + magM[k3]^2)) + 
    (dot[k1, k3]^2*F2ker[k2, k3])/(magM[k1]^2*(2*dot[k2, k3] + magM[k2]^2 + 
       magM[k3]^2)))/3, 1, 1, 1, 1, dot[k1, k2]^2/(3*magM[k1]^2*magM[k2]^2) + 
  dot[k1, k3]^2/(3*magM[k1]^2*magM[k3]^2) + 
  dot[k2, k3]^2/(3*magM[k2]^2*magM[k3]^2), 
 dot[k1, k2]^2/(3*magM[k1]^2*magM[k2]^2) + 
  dot[k1, k3]^2/(3*magM[k1]^2*magM[k3]^2) + 
  dot[k2, k3]^2/(3*magM[k2]^2*magM[k3]^2), 
 dot[k1, k2]^2/(3*magM[k1]^2*magM[k2]^2) + 
  dot[k1, k3]^2/(3*magM[k1]^2*magM[k3]^2) + 
  dot[k2, k3]^2/(3*magM[k2]^2*magM[k3]^2), 
 dot[k1, k2]^2/(3*magM[k1]^2*magM[k2]^2) + 
  dot[k1, k3]^2/(3*magM[k1]^2*magM[k3]^2) + 
  dot[k2, k3]^2/(3*magM[k2]^2*magM[k3]^2), 
 dot[k1, k2]^2/(3*magM[k1]^2*magM[k2]^2) + 
  dot[k1, k3]^2/(3*magM[k1]^2*magM[k3]^2) + 
  dot[k2, k3]^2/(3*magM[k2]^2*magM[k3]^2), 
 dot[k1, k2]^2/(3*magM[k1]^2*magM[k2]^2) + 
  dot[k1, k3]^2/(3*magM[k1]^2*magM[k3]^2) + 
  dot[k2, k3]^2/(3*magM[k2]^2*magM[k3]^2), 
 (dot[k1, k2]*dot[k1, k3]*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 (dot[k1, k2]*dot[k1, k3]*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 (dot[k1, k2]*dot[k1, k3]*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2), 
 (dot[k1, k2]*dot[k1, k3]*dot[k2, k3])/(magM[k1]^2*magM[k2]^2*magM[k3]^2)}
