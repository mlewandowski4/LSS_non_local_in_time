(* Created with the Wolfram Language : www.wolfram.com *)
{-Cker2[\[Delta]][1] + Cker2[\[Theta]][1] == 0, 
 (-4*Cker2[r2][1])/7 - (3*Cker2[\[Delta]^2][1])/7 + Cker2[\[Theta]][2] == 0, 
 (-2*Cker2[r2][1])/7 + Cker2[\[Delta]][2] - (5*Cker2[\[Delta]^2][1])/7 == 0, 
 -Cker2[\[Delta]^2][1] + Cker2[\[Theta]^2][1] == 0, 
 -Cker2[\[Delta]^2][1] + Cker2[\[Delta]*\[Theta]][1] == 0, 
 Cker2[p2][1] - Cker2[r2][1] == 0, -Cker2[r2][1] + Cker2[rp][1] == 0}
