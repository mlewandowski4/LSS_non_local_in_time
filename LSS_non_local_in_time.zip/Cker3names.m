(* Created with the Wolfram Language : www.wolfram.com *)
{Cker3[\[Theta]][1], Cker3[\[Theta]][2], Cker3[\[Theta]][3], 
 Cker3[\[Delta]][1], Cker3[\[Delta]][2], Cker3[\[Delta]][3], 
 Cker3[\[Theta]^2][1], Cker3[\[Theta]^2][2], Cker3[\[Delta]*\[Theta]][1], 
 Cker3[\[Delta]*\[Theta]][2], Cker3[\[Delta]^2][1], Cker3[\[Delta]^2][2], 
 Cker3[p2][1], Cker3[p2][2], Cker3[rp][1], Cker3[rp][2], Cker3[r2][1], 
 Cker3[r2][2], Cker3[\[Theta]^3][1], Cker3[\[Delta]*\[Theta]^2][1], 
 Cker3[\[Delta]^2*\[Theta]][1], Cker3[\[Delta]^3][1], Cker3[p2*\[Theta]][1], 
 Cker3[p2*\[Delta]][1], Cker3[rp*\[Theta]][1], Cker3[rp*\[Delta]][1], 
 Cker3[r2*\[Theta]][1], Cker3[r2*\[Delta]][1], Cker3[p3][1], Cker3[rp2][1], 
 Cker3[r2p][1], Cker3[r3][1]}
