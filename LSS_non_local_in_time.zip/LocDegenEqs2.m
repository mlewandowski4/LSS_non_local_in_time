(* Created with the Wolfram Language : www.wolfram.com *)
{(-2*\[ScriptCapitalO]ker2[r2])/7 - \[ScriptCapitalO]ker2[\[Delta]] + 
   (2*\[ScriptCapitalO]ker2[\[Delta]^2])/7 + \[ScriptCapitalO]ker2[
    \[Theta]] == 0, -\[ScriptCapitalO]ker2[\[Delta]^2] + 
   \[ScriptCapitalO]ker2[\[Theta]^2] == 0, 
 -\[ScriptCapitalO]ker2[\[Delta]^2] + \[ScriptCapitalO]ker2[
    \[Delta]*\[Theta]] == 0, \[ScriptCapitalO]ker2[p2] - 
   \[ScriptCapitalO]ker2[r2] == 0, 
 -\[ScriptCapitalO]ker2[r2] + \[ScriptCapitalO]ker2[rp] == 0}
