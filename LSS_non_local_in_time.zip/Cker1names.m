(* Created with the Wolfram Language : www.wolfram.com *)
{Cker1[\[Theta]][1], Cker1[\[Delta]][1]}
