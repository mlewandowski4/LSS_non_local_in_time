(* Created with the Wolfram Language : www.wolfram.com *)
{Cker5[\[Delta]][1] - Cker5[\[Theta]][1] == 0, 
 (-2*Cker5[p2][1])/7 + Cker5[\[Delta]][2] - (5*Cker5[\[Theta]^2][1])/7 == 0, 
 -1/9*Cker5[p2][2] + Cker5[\[Delta]][3] - Cker5[p2*\[Theta]][1]/3 - 
   (4*Cker5[\[Theta]^3][1])/9 == 0, 
 (-2*Cker5[p2][3])/33 + (80*Cker5[rprp][1])/1617 + Cker5[\[Delta]][4] - 
   (4*Cker5[p2*\[Theta]][2])/33 - (320*Cker5[rp2*\[Theta]][1])/4851 - 
   (40*Cker5[rp*\[Theta]^2][1])/231 - (1285*Cker5[\[Theta]^4][1])/4851 == 0, 
 -1/26*Cker5[p2][4] + (5*Cker5[rprp][2])/273 + Cker5[\[Delta]][5] - 
   (5*Cker5[p2*\[Theta]][3])/78 - (535*Cker5[r3*\[Theta]][2])/6552 + 
   (185*Cker5[rp2*\[Theta]][2])/2184 - (1135*Cker5[rp*\[Delta]*\[Theta]][2])/
    6552 + (20*Cker5[r2*\[Theta]^2][2])/63 - (1675*Cker5[rp*\[Theta]^2][2])/
    6552 - (389*Cker5[\[Delta]*\[Theta]^3][2])/936 + 
   (2557*Cker5[\[Theta]^4][2])/6552 == 0, 
 (-4*Cker5[p2][1])/7 + Cker5[\[Theta]][2] - (3*Cker5[\[Theta]^2][1])/7 == 0, 
 -1/3*Cker5[p2][2] + Cker5[\[Theta]][3] - Cker5[p2*\[Theta]][1]/7 - 
   (4*Cker5[\[Theta]^3][1])/21 == 0, 
 (-8*Cker5[p2][3])/33 + (80*Cker5[rprp][1])/4851 + Cker5[\[Theta]][4] - 
   (4*Cker5[p2*\[Theta]][2])/99 - (320*Cker5[rp2*\[Theta]][1])/14553 - 
   (40*Cker5[rp*\[Theta]^2][1])/693 - (1285*Cker5[\[Theta]^4][1])/14553 == 0, 
 (-5*Cker5[p2][4])/26 + (5*Cker5[rprp][2])/1001 + Cker5[\[Theta]][5] - 
   (5*Cker5[p2*\[Theta]][3])/286 - (535*Cker5[r3*\[Theta]][2])/24024 + 
   (185*Cker5[rp2*\[Theta]][2])/8008 - (1135*Cker5[rp*\[Delta]*\[Theta]][2])/
    24024 + (20*Cker5[r2*\[Theta]^2][2])/231 - (1675*Cker5[rp*\[Theta]^2][2])/
    24024 - (389*Cker5[\[Delta]*\[Theta]^3][2])/3432 + 
   (2557*Cker5[\[Theta]^4][2])/24024 == 0, 
 Cker5[\[Delta]^2][1] - Cker5[\[Theta]^2][1] == 0, 
 Cker5[\[Delta]^2][2] - (4*Cker5[p2*\[Theta]][1])/7 - 
   (10*Cker5[\[Theta]^3][1])/7 == 0, 
 (40*Cker5[rprp][1])/441 + Cker5[\[Delta]^2][3] - 
   (2*Cker5[p2*\[Theta]][2])/9 - (160*Cker5[rp2*\[Theta]][1])/1323 - 
   (8*Cker5[rp*\[Theta]^2][1])/9 - (1871*Cker5[\[Theta]^4][1])/1323 == 0, 
 (8*Cker5[rprp][2])/231 + Cker5[\[Delta]^2][4] - (4*Cker5[p2*\[Theta]][3])/
    33 - (107*Cker5[r3*\[Theta]][2])/693 + (37*Cker5[rp2*\[Theta]][2])/231 - 
   (149*Cker5[rp*\[Delta]*\[Theta]][2])/231 + (190*Cker5[r2*\[Theta]^2][2])/
    231 - (47*Cker5[rp*\[Theta]^2][2])/77 - 
   (370*Cker5[\[Delta]*\[Theta]^3][2])/231 + (815*Cker5[\[Theta]^4][2])/
    693 == 0, Cker5[\[Delta]*\[Theta]][1] - Cker5[\[Theta]^2][1] == 0, 
 (-6*Cker5[p2*\[Theta]][1])/7 + Cker5[\[Delta]*\[Theta]][2] - 
   (8*Cker5[\[Theta]^3][1])/7 == 0, 
 (80*Cker5[rprp][1])/441 - (4*Cker5[p2*\[Theta]][2])/9 - 
   (320*Cker5[rp2*\[Theta]][1])/1323 + Cker5[\[Delta]*\[Theta]][3] - 
   (40*Cker5[rp*\[Theta]^2][1])/63 - (1285*Cker5[\[Theta]^4][1])/1323 == 0, 
 (20*Cker5[rprp][2])/231 - (10*Cker5[p2*\[Theta]][3])/33 - 
   (535*Cker5[r3*\[Theta]][2])/1386 + (185*Cker5[rp2*\[Theta]][2])/462 + 
   Cker5[\[Delta]*\[Theta]][4] - (1135*Cker5[rp*\[Delta]*\[Theta]][2])/1386 + 
   (1040*Cker5[r2*\[Theta]^2][2])/693 - (1675*Cker5[rp*\[Theta]^2][2])/1386 - 
   (389*Cker5[\[Delta]*\[Theta]^3][2])/198 + (2557*Cker5[\[Theta]^4][2])/
    1386 == 0, (-8*Cker5[p2*\[Theta]][1])/7 + Cker5[\[Theta]^2][2] - 
   (6*Cker5[\[Theta]^3][1])/7 == 0, 
 (16*Cker5[rprp][1])/147 - (2*Cker5[p2*\[Theta]][2])/3 - 
   (64*Cker5[rp2*\[Theta]][1])/441 + Cker5[\[Theta]^2][3] - 
   (8*Cker5[rp*\[Theta]^2][1])/21 - (257*Cker5[\[Theta]^4][1])/441 == 0, 
 (10*Cker5[rprp][2])/231 - (16*Cker5[p2*\[Theta]][3])/33 - 
   (535*Cker5[r3*\[Theta]][2])/2772 + (185*Cker5[rp2*\[Theta]][2])/924 - 
   (1135*Cker5[rp*\[Delta]*\[Theta]][2])/2772 + Cker5[\[Theta]^2][4] + 
   (520*Cker5[r2*\[Theta]^2][2])/693 - (1675*Cker5[rp*\[Theta]^2][2])/2772 - 
   (389*Cker5[\[Delta]*\[Theta]^3][2])/396 + (2557*Cker5[\[Theta]^4][2])/
    2772 == 0, -Cker5[p2][1] + Cker5[r2][1] == 0, 
 (-5*Cker5[p2][2])/3 + (4*Cker5[p3][1])/3 + Cker5[r2][2] == 0, 
 -Cker5[p2][1] + Cker5[rp][1] == 0, 
 (-4*Cker5[p2][2])/3 + (2*Cker5[p3][1])/3 + Cker5[rp][2] == 0, 
 (-5*Cker5[p2][3])/3 + (2*Cker5[p3][2])/3 + Cker5[rp][3] == 0, 
 -2*Cker5[p2][4] + (2*Cker5[p3][3])/3 + Cker5[rp][4] == 0, 
 Cker5[\[Delta]^3][1] - Cker5[\[Theta]^3][1] == 0, 
 Cker5[\[Delta]^3][2] - (6*Cker5[rp*\[Theta]^2][1])/7 - 
   (15*Cker5[\[Theta]^4][1])/7 == 0, 
 Cker5[\[Delta]^3][3] - (10*Cker5[rp*\[Delta]*\[Theta]][2])/21 + 
   Cker5[r2*\[Theta]^2][2]/3 - (4*Cker5[rp*\[Theta]^2][2])/21 - 
   (127*Cker5[\[Delta]*\[Theta]^3][2])/42 + (13*Cker5[\[Theta]^4][2])/7 == 0, 
 Cker5[\[Delta]^2*\[Theta]][1] - Cker5[\[Theta]^3][1] == 0, 
 Cker5[\[Delta]^2*\[Theta]][2] - (8*Cker5[rp*\[Theta]^2][1])/7 - 
   (13*Cker5[\[Theta]^4][1])/7 == 0, 
 (-50*Cker5[rp*\[Delta]*\[Theta]][2])/63 + Cker5[\[Delta]^2*\[Theta]][3] + 
   (5*Cker5[r2*\[Theta]^2][2])/9 - (20*Cker5[rp*\[Theta]^2][2])/63 - 
   (257*Cker5[\[Delta]*\[Theta]^3][2])/126 + (23*Cker5[\[Theta]^4][2])/21 == 
  0, Cker5[\[Delta]*\[Theta]^2][1] - Cker5[\[Theta]^3][1] == 0, 
 (-10*Cker5[rp*\[Theta]^2][1])/7 + Cker5[\[Delta]*\[Theta]^2][2] - 
   (11*Cker5[\[Theta]^4][1])/7 == 0, 
 (-52*Cker5[rp*\[Delta]*\[Theta]][2])/63 + (7*Cker5[r2*\[Theta]^2][2])/9 - 
   (46*Cker5[rp*\[Theta]^2][2])/63 + Cker5[\[Delta]*\[Theta]^2][3] - 
   (169*Cker5[\[Delta]*\[Theta]^3][2])/126 + (13*Cker5[\[Theta]^4][2])/21 == 
  0, (-12*Cker5[rp*\[Theta]^2][1])/7 + Cker5[\[Theta]^3][2] - 
   (9*Cker5[\[Theta]^4][1])/7 == 0, 
 (-4*Cker5[rp*\[Delta]*\[Theta]][2])/7 + Cker5[r2*\[Theta]^2][2] - 
   (10*Cker5[rp*\[Theta]^2][2])/7 + Cker5[\[Theta]^3][3] - 
   (13*Cker5[\[Delta]*\[Theta]^3][2])/14 + (3*Cker5[\[Theta]^4][2])/7 == 0, 
 -Cker5[p3][1] + Cker5[r3][1] == 0, 
 (-5*Cker5[p3][2])/3 + Cker5[r3][2] + 2*Cker5[rprp][1] == 0, 
 (10*Cker5[p3][3])/3 - 3*Cker5[r2p][3] + Cker5[r3][3] - 
   (3*Cker5[rprp][2])/2 + (385*Cker5[r3*\[Theta]][2])/48 - 
   (175*Cker5[rp2*\[Theta]][2])/16 + (115*Cker5[rp*\[Delta]*\[Theta]][2])/
    16 - (45*Cker5[r2*\[Theta]^2][2])/2 + (335*Cker5[rp*\[Theta]^2][2])/16 + 
   (371*Cker5[\[Delta]*\[Theta]^3][2])/16 - (1267*Cker5[\[Theta]^4][2])/48 == 
  0, -Cker5[p3][1] + Cker5[r2p][1] == 0, 
 (-13*Cker5[p3][2])/9 + Cker5[r2p][2] + (4*Cker5[rprp][1])/3 == 0, 
 -Cker5[p3][1] + Cker5[rp2][1] == 0, 
 (-11*Cker5[p3][2])/9 + Cker5[rp2][2] + (2*Cker5[rprp][1])/3 == 0, 
 (-13*Cker5[p3][3])/9 + Cker5[rp2][3] + Cker5[rprp][2]/2 - 
   (385*Cker5[r3*\[Theta]][2])/144 + (175*Cker5[rp2*\[Theta]][2])/48 - 
   (115*Cker5[rp*\[Delta]*\[Theta]][2])/48 + (15*Cker5[r2*\[Theta]^2][2])/2 - 
   (335*Cker5[rp*\[Theta]^2][2])/48 - (371*Cker5[\[Delta]*\[Theta]^3][2])/
    48 + (1267*Cker5[\[Theta]^4][2])/144 == 0, 
 Cker5[r2*\[Delta]][1] - Cker5[p2*\[Theta]][1] == 0, 
 (4*Cker5[rprp][1])/3 + Cker5[r2*\[Delta]][2] - (5*Cker5[p2*\[Theta]][2])/3 - 
   (4*Cker5[rp2*\[Theta]][1])/9 + (4*Cker5[rp*\[Theta]^2][1])/3 - 
   (2*Cker5[\[Theta]^4][1])/9 == 0, 
 (11*Cker5[rprp][2])/21 + Cker5[r2*\[Delta]][3] - Cker5[r2*\[Theta]][3] - 
   (253*Cker5[r3*\[Theta]][2])/504 - (13*Cker5[rp2*\[Theta]][2])/168 - 
   (293*Cker5[rp*\[Delta]*\[Theta]][2])/504 + (61*Cker5[r2*\[Theta]^2][2])/
    63 - (233*Cker5[rp*\[Theta]^2][2])/504 - 
   (853*Cker5[\[Delta]*\[Theta]^3][2])/504 + (919*Cker5[\[Theta]^4][2])/
    504 == 0, Cker5[rp*\[Delta]][1] - Cker5[p2*\[Theta]][1] == 0, 
 (20*Cker5[rprp][1])/21 + Cker5[rp*\[Delta]][2] - 
   (4*Cker5[p2*\[Theta]][2])/3 - (38*Cker5[rp2*\[Theta]][1])/63 + 
   (17*Cker5[rp*\[Theta]^2][1])/21 - (10*Cker5[\[Theta]^4][1])/63 == 0, 
 (16*Cker5[rprp][2])/21 + Cker5[rp*\[Delta]][3] - 
   (5*Cker5[p2*\[Theta]][3])/3 - (709*Cker5[r3*\[Theta]][2])/252 + 
   (275*Cker5[rp2*\[Theta]][2])/84 - (677*Cker5[rp*\[Delta]*\[Theta]][2])/
    252 + (461*Cker5[r2*\[Theta]^2][2])/63 - (1481*Cker5[rp*\[Theta]^2][2])/
    252 - (2161*Cker5[\[Delta]*\[Theta]^3][2])/252 + 
   (2419*Cker5[\[Theta]^4][2])/252 == 0, 
 Cker5[p2*\[Delta]][1] - Cker5[p2*\[Theta]][1] == 0, 
 (4*Cker5[rprp][1])/7 + Cker5[p2*\[Delta]][2] - Cker5[p2*\[Theta]][2] - 
   (16*Cker5[rp2*\[Theta]][1])/21 + (2*Cker5[rp*\[Theta]^2][1])/7 - 
   (2*Cker5[\[Theta]^4][1])/21 == 0, 
 (8*Cker5[rprp][2])/21 + Cker5[p2*\[Delta]][3] - Cker5[p2*\[Theta]][3] - 
   (107*Cker5[r3*\[Theta]][2])/63 + (37*Cker5[rp2*\[Theta]][2])/21 - 
   (145*Cker5[rp*\[Delta]*\[Theta]][2])/63 + (346*Cker5[r2*\[Theta]^2][2])/
    63 - (277*Cker5[rp*\[Theta]^2][2])/63 - 
   (383*Cker5[\[Delta]*\[Theta]^3][2])/63 + (431*Cker5[\[Theta]^4][2])/63 == 
  0, -Cker5[p2*\[Theta]][1] + Cker5[r2*\[Theta]][1] == 0, 
 (16*Cker5[rprp][1])/21 - (5*Cker5[p2*\[Theta]][2])/3 + 
   Cker5[r2*\[Theta]][2] + (20*Cker5[rp2*\[Theta]][1])/63 + 
   (22*Cker5[rp*\[Theta]^2][1])/21 - (8*Cker5[\[Theta]^4][1])/63 == 0, 
 -Cker5[p2*\[Theta]][1] + Cker5[rp*\[Theta]][1] == 0, 
 (8*Cker5[rprp][1])/21 - (4*Cker5[p2*\[Theta]][2])/3 + 
   Cker5[rp*\[Theta]][2] + (10*Cker5[rp2*\[Theta]][1])/63 + 
   (11*Cker5[rp*\[Theta]^2][1])/21 - (4*Cker5[\[Theta]^4][1])/63 == 0, 
 (13*Cker5[rprp][2])/42 - (5*Cker5[p2*\[Theta]][3])/3 - 
   (1727*Cker5[r3*\[Theta]][2])/1008 + Cker5[rp*\[Theta]][3] + 
   (817*Cker5[rp2*\[Theta]][2])/336 - (1255*Cker5[rp*\[Delta]*\[Theta]][2])/
    1008 + (515*Cker5[r2*\[Theta]^2][2])/126 - (3475*Cker5[rp*\[Theta]^2][2])/
    1008 - (4727*Cker5[\[Delta]*\[Theta]^3][2])/1008 + 
   (5309*Cker5[\[Theta]^4][2])/1008 == 0, 
 Cker5[\[Delta]^4][1] - Cker5[\[Theta]^4][1] == 0, 
 Cker5[\[Delta]^4][2] - 4*Cker5[\[Delta]*\[Theta]^3][2] + 
   3*Cker5[\[Theta]^4][2] == 0, 
 Cker5[r3*\[Delta]][1] - Cker5[rp2*\[Theta]][1] == 0, 
 Cker5[r3*\[Delta]][2] - (19*Cker5[r3*\[Theta]][2])/8 + 
   (15*Cker5[rp2*\[Theta]][2])/8 - (19*Cker5[rp*\[Delta]*\[Theta]][2])/8 + 
   5*Cker5[r2*\[Theta]^2][2] - (31*Cker5[rp*\[Theta]^2][2])/8 - 
   (43*Cker5[\[Delta]*\[Theta]^3][2])/8 + (49*Cker5[\[Theta]^4][2])/8 == 0, 
 Cker5[r2*\[Delta]^2][1] - Cker5[rp*\[Theta]^2][1] == 0, 
 Cker5[r2*\[Delta]^2][2] - 2*Cker5[rp*\[Delta]*\[Theta]][2] - 
   Cker5[r2*\[Theta]^2][2] + 2*Cker5[rp*\[Theta]^2][2] == 0, 
 Cker5[r2^2][1] - 2*Cker5[rprp][1] + (8*Cker5[rp2*\[Theta]][1])/3 - 
   2*Cker5[rp*\[Theta]^2][1] + Cker5[\[Theta]^4][1]/3 == 0, 
 Cker5[r2^2][2] - (5*Cker5[rprp][2])/2 - (27*Cker5[r3*\[Theta]][2])/16 + 
   (95*Cker5[rp2*\[Theta]][2])/16 - (233*Cker5[rp*\[Delta]*\[Theta]][2])/48 + 
   (43*Cker5[r2*\[Theta]^2][2])/6 - (317*Cker5[rp*\[Theta]^2][2])/48 - 
   (361*Cker5[\[Delta]*\[Theta]^3][2])/48 + (145*Cker5[\[Theta]^4][2])/16 == 
  0, Cker5[r4][1] - Cker5[rprp][1] == 0, 
 Cker5[r4][2] - (5*Cker5[rprp][2])/4 - (385*Cker5[r3*\[Theta]][2])/96 + 
   (175*Cker5[rp2*\[Theta]][2])/32 - (115*Cker5[rp*\[Delta]*\[Theta]][2])/
    32 + (45*Cker5[r2*\[Theta]^2][2])/4 - (335*Cker5[rp*\[Theta]^2][2])/32 - 
   (371*Cker5[\[Delta]*\[Theta]^3][2])/32 + (1267*Cker5[\[Theta]^4][2])/96 == 
  0, Cker5[p2^2][1] - 2*Cker5[rprp][1] + (8*Cker5[rp2*\[Theta]][1])/3 - 
   2*Cker5[rp*\[Theta]^2][1] + Cker5[\[Theta]^4][1]/3 == 0, 
 Cker5[p2^2][2] - (3*Cker5[rprp][2])/2 + (107*Cker5[r3*\[Theta]][2])/16 - 
   (111*Cker5[rp2*\[Theta]][2])/16 + (115*Cker5[rp*\[Delta]*\[Theta]][2])/
    16 - (41*Cker5[r2*\[Theta]^2][2])/2 + (271*Cker5[rp*\[Theta]^2][2])/16 + 
   (371*Cker5[\[Delta]*\[Theta]^3][2])/16 - (417*Cker5[\[Theta]^4][2])/16 == 
  0, Cker5[p4][1] - Cker5[rprp][1] == 0, 
 Cker5[p4][2] - (3*Cker5[rprp][2])/4 + (385*Cker5[r3*\[Theta]][2])/96 - 
   (175*Cker5[rp2*\[Theta]][2])/32 + (115*Cker5[rp*\[Delta]*\[Theta]][2])/
    32 - (45*Cker5[r2*\[Theta]^2][2])/4 + (335*Cker5[rp*\[Theta]^2][2])/32 + 
   (371*Cker5[\[Delta]*\[Theta]^3][2])/32 - (1267*Cker5[\[Theta]^4][2])/96 == 
  0, Cker5[p2*r2][1] - 2*Cker5[rprp][1] + (8*Cker5[rp2*\[Theta]][1])/3 - 
   2*Cker5[rp*\[Theta]^2][1] + Cker5[\[Theta]^4][1]/3 == 0, 
 Cker5[p2*r2][2] - 2*Cker5[rprp][2] + (5*Cker5[r3*\[Theta]][2])/2 - 
   Cker5[rp2*\[Theta]][2]/2 + (7*Cker5[rp*\[Delta]*\[Theta]][2])/6 - 
   (20*Cker5[r2*\[Theta]^2][2])/3 + (31*Cker5[rp*\[Theta]^2][2])/6 + 
   (47*Cker5[\[Delta]*\[Theta]^3][2])/6 - (17*Cker5[\[Theta]^4][2])/2 == 0, 
 Cker5[r2p2][1] - Cker5[rprp][1] == 0, Cker5[r2p2][2] - Cker5[rprp][2] == 0, 
 Cker5[r2*r3][1] + (77*Cker5[r3*\[Theta]][2])/16 - 
   (105*Cker5[rp2*\[Theta]][2])/16 + (101*Cker5[rp*\[Delta]*\[Theta]][2])/
    16 - (31*Cker5[r2*\[Theta]^2][2])/2 + (209*Cker5[rp*\[Theta]^2][2])/16 + 
   (277*Cker5[\[Delta]*\[Theta]^3][2])/16 - (315*Cker5[\[Theta]^4][2])/16 == 
  0, Cker5[r3p][1] - Cker5[rprp][1] == 0, 
 Cker5[r3p][2] - (9*Cker5[rprp][2])/8 - (385*Cker5[r3*\[Theta]][2])/192 + 
   (175*Cker5[rp2*\[Theta]][2])/64 - (115*Cker5[rp*\[Delta]*\[Theta]][2])/
    64 + (45*Cker5[r2*\[Theta]^2][2])/8 - (335*Cker5[rp*\[Theta]^2][2])/64 - 
   (371*Cker5[\[Delta]*\[Theta]^3][2])/64 + (1267*Cker5[\[Theta]^4][2])/
    192 == 0, Cker5[r5][1] + (385*Cker5[r3*\[Theta]][2])/96 - 
   (175*Cker5[rp2*\[Theta]][2])/32 + (115*Cker5[rp*\[Delta]*\[Theta]][2])/
    32 - (45*Cker5[r2*\[Theta]^2][2])/4 + (335*Cker5[rp*\[Theta]^2][2])/32 + 
   (371*Cker5[\[Delta]*\[Theta]^3][2])/32 - (1267*Cker5[\[Theta]^4][2])/96 == 
  0, Cker5[p2*rp][1] - 2*Cker5[rprp][1] + (8*Cker5[rp2*\[Theta]][1])/3 - 
   2*Cker5[rp*\[Theta]^2][1] + Cker5[\[Theta]^4][1]/3 == 0, 
 Cker5[p2*rp][2] - (7*Cker5[rprp][2])/4 + (147*Cker5[r3*\[Theta]][2])/32 - 
   (119*Cker5[rp2*\[Theta]][2])/32 + (401*Cker5[rp*\[Delta]*\[Theta]][2])/
    96 - (163*Cker5[r2*\[Theta]^2][2])/12 + (1061*Cker5[rp*\[Theta]^2][2])/
    96 + (1489*Cker5[\[Delta]*\[Theta]^3][2])/96 - 
   (553*Cker5[\[Theta]^4][2])/32 == 0, 
 Cker5[r2*rp][1] - 2*Cker5[rprp][1] + (8*Cker5[rp2*\[Theta]][1])/3 - 
   2*Cker5[rp*\[Theta]^2][1] + Cker5[\[Theta]^4][1]/3 == 0, 
 Cker5[r2*rp][2] - (9*Cker5[rprp][2])/4 + (13*Cker5[r3*\[Theta]][2])/32 + 
   (87*Cker5[rp2*\[Theta]][2])/32 - (59*Cker5[rp*\[Delta]*\[Theta]][2])/32 + 
   Cker5[r2*\[Theta]^2][2]/4 - (23*Cker5[rp*\[Theta]^2][2])/32 + 
   (5*Cker5[\[Delta]*\[Theta]^3][2])/32 + (9*Cker5[\[Theta]^4][2])/32 == 0, 
 Cker5[rp^2][1] - 2*Cker5[rprp][1] + (8*Cker5[rp2*\[Theta]][1])/3 - 
   2*Cker5[rp*\[Theta]^2][1] + Cker5[\[Theta]^4][1]/3 == 0, 
 Cker5[rp^2][2] - 2*Cker5[rprp][2] + (5*Cker5[r3*\[Theta]][2])/2 - 
   Cker5[rp2*\[Theta]][2]/2 + (7*Cker5[rp*\[Delta]*\[Theta]][2])/6 - 
   (20*Cker5[r2*\[Theta]^2][2])/3 + (31*Cker5[rp*\[Theta]^2][2])/6 + 
   (47*Cker5[\[Delta]*\[Theta]^3][2])/6 - (17*Cker5[\[Theta]^4][2])/2 == 0, 
 Cker5[rp3][1] - Cker5[rprp][1] == 0, 
 Cker5[rp3][2] - (7*Cker5[rprp][2])/8 + (385*Cker5[r3*\[Theta]][2])/192 - 
   (175*Cker5[rp2*\[Theta]][2])/64 + (115*Cker5[rp*\[Delta]*\[Theta]][2])/
    64 - (45*Cker5[r2*\[Theta]^2][2])/8 + (335*Cker5[rp*\[Theta]^2][2])/64 + 
   (371*Cker5[\[Delta]*\[Theta]^3][2])/64 - (1267*Cker5[\[Theta]^4][2])/
    192 == 0, Cker5[p3*\[Delta]][1] - Cker5[rp2*\[Theta]][1] == 0, 
 Cker5[p3*\[Delta]][2] - (7*Cker5[r3*\[Theta]][2])/8 + 
   (3*Cker5[rp2*\[Theta]][2])/8 - (19*Cker5[rp*\[Delta]*\[Theta]][2])/8 + 
   5*Cker5[r2*\[Theta]^2][2] - (31*Cker5[rp*\[Theta]^2][2])/8 - 
   (43*Cker5[\[Delta]*\[Theta]^3][2])/8 + (49*Cker5[\[Theta]^4][2])/8 == 0, 
 Cker5[r2^2*\[Delta]][1] + (7*Cker5[rp*\[Delta]*\[Theta]][2])/2 - 
   (7*Cker5[rp*\[Theta]^2][2])/2 + (3*Cker5[\[Delta]*\[Theta]^3][2])/2 - 
   (7*Cker5[\[Theta]^4][2])/4 == 0, 
 Cker5[r2p*\[Delta]][1] - Cker5[rp2*\[Theta]][1] == 0, 
 Cker5[r2p*\[Delta]][2] - (15*Cker5[r3*\[Theta]][2])/8 + 
   (11*Cker5[rp2*\[Theta]][2])/8 - (19*Cker5[rp*\[Delta]*\[Theta]][2])/8 + 
   5*Cker5[r2*\[Theta]^2][2] - (31*Cker5[rp*\[Theta]^2][2])/8 - 
   (43*Cker5[\[Delta]*\[Theta]^3][2])/8 + (49*Cker5[\[Theta]^4][2])/8 == 0, 
 Cker5[r4*\[Delta]][1] - (11*Cker5[rp*\[Delta]*\[Theta]][2])/12 + 
   (8*Cker5[r2*\[Theta]^2][2])/3 - (29*Cker5[rp*\[Theta]^2][2])/12 - 
   (37*Cker5[\[Delta]*\[Theta]^3][2])/12 + (7*Cker5[\[Theta]^4][2])/2 == 0, 
 Cker5[rp2*\[Delta]][1] - Cker5[rp2*\[Theta]][1] == 0, 
 Cker5[rp2*\[Delta]][2] - (11*Cker5[r3*\[Theta]][2])/8 + 
   (7*Cker5[rp2*\[Theta]][2])/8 - (19*Cker5[rp*\[Delta]*\[Theta]][2])/8 + 
   5*Cker5[r2*\[Theta]^2][2] - (31*Cker5[rp*\[Theta]^2][2])/8 - 
   (43*Cker5[\[Delta]*\[Theta]^3][2])/8 + (49*Cker5[\[Theta]^4][2])/8 == 0, 
 Cker5[p2*\[Delta]^2][1] - Cker5[rp*\[Theta]^2][1] == 0, 
 Cker5[p2*\[Delta]^2][2] - 2*Cker5[rp*\[Delta]*\[Theta]][2] + 
   Cker5[r2*\[Theta]^2][2] == 0, 
 Cker5[r3*\[Delta]^2][1] - 2*Cker5[rp*\[Delta]*\[Theta]][2] + 
   2*Cker5[r2*\[Theta]^2][2] - Cker5[rp*\[Theta]^2][2]/2 - 
   (3*Cker5[\[Delta]*\[Theta]^3][2])/2 + (7*Cker5[\[Theta]^4][2])/4 == 0, 
 Cker5[rp*\[Delta]^2][1] - Cker5[rp*\[Theta]^2][1] == 0, 
 Cker5[rp*\[Delta]^2][2] - 2*Cker5[rp*\[Delta]*\[Theta]][2] + 
   Cker5[rp*\[Theta]^2][2] == 0, 
 Cker5[r2*\[Delta]^3][1] + (3*Cker5[\[Delta]*\[Theta]^3][2])/2 - 
   (7*Cker5[\[Theta]^4][2])/4 == 0, 
 Cker5[\[Delta]^5][1] - 2*Cker5[\[Delta]*\[Theta]^3][2] + 
   (7*Cker5[\[Theta]^4][2])/4 == 0, 
 Cker5[p3*\[Theta]][1] - Cker5[rp2*\[Theta]][1] == 0, 
 Cker5[p3*\[Theta]][2] + Cker5[r3*\[Theta]][2]/2 - 
   (3*Cker5[rp2*\[Theta]][2])/2 == 0, 
 Cker5[r2p*\[Theta]][1] - Cker5[rp2*\[Theta]][1] == 0, 
 Cker5[r2p*\[Theta]][2] - Cker5[r3*\[Theta]][2]/2 - 
   Cker5[rp2*\[Theta]][2]/2 == 0, 
 Cker5[r3*\[Theta]][1] - Cker5[rp2*\[Theta]][1] == 0, 
 Cker5[p2*\[Delta]*\[Theta]][1] - Cker5[rp*\[Theta]^2][1] == 0, 
 Cker5[p2*\[Delta]*\[Theta]][2] - Cker5[rp*\[Delta]*\[Theta]][2] + 
   Cker5[r2*\[Theta]^2][2] - Cker5[rp*\[Theta]^2][2] == 0, 
 Cker5[r2*\[Delta]*\[Theta]][1] - Cker5[rp*\[Theta]^2][1] == 0, 
 Cker5[r2*\[Delta]*\[Theta]][2] - Cker5[rp*\[Delta]*\[Theta]][2] - 
   Cker5[r2*\[Theta]^2][2] + Cker5[rp*\[Theta]^2][2] == 0, 
 Cker5[rp*\[Delta]*\[Theta]][1] - Cker5[rp*\[Theta]^2][1] == 0, 
 Cker5[\[Delta]^3*\[Theta]][1] - Cker5[\[Theta]^4][1] == 0, 
 Cker5[\[Delta]^3*\[Theta]][2] - 3*Cker5[\[Delta]*\[Theta]^3][2] + 
   2*Cker5[\[Theta]^4][2] == 0, 
 Cker5[p2*\[Theta]^2][1] - Cker5[rp*\[Theta]^2][1] == 0, 
 Cker5[p2*\[Theta]^2][2] + Cker5[r2*\[Theta]^2][2] - 
   2*Cker5[rp*\[Theta]^2][2] == 0, 
 Cker5[r2*\[Theta]^2][1] - Cker5[rp*\[Theta]^2][1] == 0, 
 Cker5[\[Delta]^2*\[Theta]^2][1] - Cker5[\[Theta]^4][1] == 0, 
 Cker5[\[Delta]^2*\[Theta]^2][2] - 2*Cker5[\[Delta]*\[Theta]^3][2] + 
   Cker5[\[Theta]^4][2] == 0, Cker5[\[Delta]*\[Theta]^3][1] - 
   Cker5[\[Theta]^4][1] == 0}
