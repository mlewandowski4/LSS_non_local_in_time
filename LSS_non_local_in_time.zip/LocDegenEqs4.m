(* Created with the Wolfram Language : www.wolfram.com *)
{(160*\[ScriptCapitalO]ker4[r2^2])/147 - (344*\[ScriptCapitalO]ker4[r4])/
    147 + (20*\[ScriptCapitalO]ker4[r2*\[Delta]])/21 + 
   (496*\[ScriptCapitalO]ker4[r3*\[Delta]])/147 - 
   (32*\[ScriptCapitalO]ker4[rp*\[Delta]])/21 - \[ScriptCapitalO]ker4[
    \[Delta]^2] - (104*\[ScriptCapitalO]ker4[r2*\[Delta]^2])/49 + 
   (4*\[ScriptCapitalO]ker4[\[Delta]^3])/7 + \[ScriptCapitalO]ker4[
    \[Theta]^2] == 0, (68*\[ScriptCapitalO]ker4[r2^2])/147 - 
   (136*\[ScriptCapitalO]ker4[r4])/147 + 
   (10*\[ScriptCapitalO]ker4[r2*\[Delta]])/21 + 
   (200*\[ScriptCapitalO]ker4[r3*\[Delta]])/147 - 
   (16*\[ScriptCapitalO]ker4[rp*\[Delta]])/21 - \[ScriptCapitalO]ker4[
    \[Delta]^2] - (44*\[ScriptCapitalO]ker4[r2*\[Delta]^2])/49 + 
   (2*\[ScriptCapitalO]ker4[\[Delta]^3])/7 + \[ScriptCapitalO]ker4[
    \[Delta]*\[Theta]] == 0, (-18*\[ScriptCapitalO]ker4[r2^2])/7 + 
   (36*\[ScriptCapitalO]ker4[r4])/7 - (48*\[ScriptCapitalO]ker4[r3*\[Delta]])/
    7 + (30*\[ScriptCapitalO]ker4[r2*\[Delta]^2])/7 - 
   \[ScriptCapitalO]ker4[\[Delta]^3] + \[ScriptCapitalO]ker4[\[Theta]^3] == 
  0, (-12*\[ScriptCapitalO]ker4[r2^2])/7 + (24*\[ScriptCapitalO]ker4[r4])/7 - 
   (32*\[ScriptCapitalO]ker4[r3*\[Delta]])/7 + 
   (20*\[ScriptCapitalO]ker4[r2*\[Delta]^2])/7 - 
   \[ScriptCapitalO]ker4[\[Delta]^3] + \[ScriptCapitalO]ker4[
    \[Delta]*\[Theta]^2] == 0, (-6*\[ScriptCapitalO]ker4[r2^2])/7 + 
   (12*\[ScriptCapitalO]ker4[r4])/7 - (16*\[ScriptCapitalO]ker4[r3*\[Delta]])/
    7 + (10*\[ScriptCapitalO]ker4[r2*\[Delta]^2])/7 - 
   \[ScriptCapitalO]ker4[\[Delta]^3] + \[ScriptCapitalO]ker4[
    \[Delta]^2*\[Theta]] == 0, (-2*\[ScriptCapitalO]ker4[r2^2])/7 + 
   \[ScriptCapitalO]ker4[r2*\[Delta]] - 
   2*\[ScriptCapitalO]ker4[rp*\[Delta]] + 
   (2*\[ScriptCapitalO]ker4[r2*\[Delta]^2])/7 + \[ScriptCapitalO]ker4[
    p2*\[Theta]] == 0, \[ScriptCapitalO]ker4[p2*\[Delta]] + 
   \[ScriptCapitalO]ker4[r2*\[Delta]] - 
   2*\[ScriptCapitalO]ker4[rp*\[Delta]] == 0, 
 (-2*\[ScriptCapitalO]ker4[r2^2])/7 - \[ScriptCapitalO]ker4[rp*\[Delta]] + 
   (2*\[ScriptCapitalO]ker4[r2*\[Delta]^2])/7 + \[ScriptCapitalO]ker4[
    rp*\[Theta]] == 0, (-2*\[ScriptCapitalO]ker4[r2^2])/7 - 
   \[ScriptCapitalO]ker4[r2*\[Delta]] + 
   (2*\[ScriptCapitalO]ker4[r2*\[Delta]^2])/7 + \[ScriptCapitalO]ker4[
    r2*\[Theta]] == 0, \[ScriptCapitalO]ker4[p3] - 
   3*\[ScriptCapitalO]ker4[r2p] + 2*\[ScriptCapitalO]ker4[r3] == 0, 
 -2*\[ScriptCapitalO]ker4[r2p] + \[ScriptCapitalO]ker4[r3] + 
   \[ScriptCapitalO]ker4[rp2] == 0, 
 3*\[ScriptCapitalO]ker4[r2^2] - 6*\[ScriptCapitalO]ker4[r4] + 
   8*\[ScriptCapitalO]ker4[r3*\[Delta]] - 
   6*\[ScriptCapitalO]ker4[r2*\[Delta]^2] + \[ScriptCapitalO]ker4[
    \[Theta]^4] == 0, 3*\[ScriptCapitalO]ker4[r2^2] - 
   6*\[ScriptCapitalO]ker4[r4] + 8*\[ScriptCapitalO]ker4[r3*\[Delta]] - 
   6*\[ScriptCapitalO]ker4[r2*\[Delta]^2] + \[ScriptCapitalO]ker4[
    \[Delta]*\[Theta]^3] == 0, 3*\[ScriptCapitalO]ker4[r2^2] - 
   6*\[ScriptCapitalO]ker4[r4] + 8*\[ScriptCapitalO]ker4[r3*\[Delta]] - 
   6*\[ScriptCapitalO]ker4[r2*\[Delta]^2] + \[ScriptCapitalO]ker4[
    \[Delta]^2*\[Theta]^2] == 0, 
 3*\[ScriptCapitalO]ker4[r2^2] - 6*\[ScriptCapitalO]ker4[r4] + 
   8*\[ScriptCapitalO]ker4[r3*\[Delta]] - 
   6*\[ScriptCapitalO]ker4[r2*\[Delta]^2] + \[ScriptCapitalO]ker4[
    \[Delta]^3*\[Theta]] == 0, 3*\[ScriptCapitalO]ker4[r2^2] - 
   6*\[ScriptCapitalO]ker4[r4] + 8*\[ScriptCapitalO]ker4[r3*\[Delta]] - 
   6*\[ScriptCapitalO]ker4[r2*\[Delta]^2] + \[ScriptCapitalO]ker4[
    \[Delta]^4] == 0, -\[ScriptCapitalO]ker4[r2*\[Delta]^2] + 
   \[ScriptCapitalO]ker4[p2*\[Theta]^2] == 0, 
 -\[ScriptCapitalO]ker4[r2*\[Delta]^2] + \[ScriptCapitalO]ker4[
    p2*\[Delta]*\[Theta]] == 0, \[ScriptCapitalO]ker4[p2*\[Delta]^2] - 
   \[ScriptCapitalO]ker4[r2*\[Delta]^2] == 0, 
 \[ScriptCapitalO]ker4[p2^2] - \[ScriptCapitalO]ker4[r2^2] == 0, 
 -\[ScriptCapitalO]ker4[r2*\[Delta]^2] + \[ScriptCapitalO]ker4[
    rp*\[Theta]^2] == 0, -\[ScriptCapitalO]ker4[r2*\[Delta]^2] + 
   \[ScriptCapitalO]ker4[rp*\[Delta]*\[Theta]] == 0, 
 -\[ScriptCapitalO]ker4[r2*\[Delta]^2] + \[ScriptCapitalO]ker4[
    rp*\[Delta]^2] == 0, -\[ScriptCapitalO]ker4[r2^2] + 
   \[ScriptCapitalO]ker4[p2*rp] == 0, 
 -\[ScriptCapitalO]ker4[r2^2] + \[ScriptCapitalO]ker4[rp^2] == 0, 
 -\[ScriptCapitalO]ker4[r2*\[Delta]^2] + \[ScriptCapitalO]ker4[
    r2*\[Theta]^2] == 0, -\[ScriptCapitalO]ker4[r2*\[Delta]^2] + 
   \[ScriptCapitalO]ker4[r2*\[Delta]*\[Theta]] == 0, 
 \[ScriptCapitalO]ker4[p2*r2] - \[ScriptCapitalO]ker4[r2^2] == 0, 
 -\[ScriptCapitalO]ker4[r2^2] + \[ScriptCapitalO]ker4[r2*rp] == 0, 
 -\[ScriptCapitalO]ker4[r3*\[Delta]] + \[ScriptCapitalO]ker4[p3*\[Theta]] == 
  0, \[ScriptCapitalO]ker4[p3*\[Delta]] - \[ScriptCapitalO]ker4[
    r3*\[Delta]] == 0, -\[ScriptCapitalO]ker4[r3*\[Delta]] + 
   \[ScriptCapitalO]ker4[rp2*\[Theta]] == 0, 
 -\[ScriptCapitalO]ker4[r3*\[Delta]] + \[ScriptCapitalO]ker4[rp2*\[Delta]] == 
  0, -\[ScriptCapitalO]ker4[r3*\[Delta]] + \[ScriptCapitalO]ker4[
    r2p*\[Theta]] == 0, \[ScriptCapitalO]ker4[r2p*\[Delta]] - 
   \[ScriptCapitalO]ker4[r3*\[Delta]] == 0, 
 -\[ScriptCapitalO]ker4[r3*\[Delta]] + \[ScriptCapitalO]ker4[r3*\[Theta]] == 
  0, \[ScriptCapitalO]ker4[p4] - \[ScriptCapitalO]ker4[r4] == 0, 
 -\[ScriptCapitalO]ker4[r4] + \[ScriptCapitalO]ker4[rp3] == 0, 
 \[ScriptCapitalO]ker4[r2p2] - \[ScriptCapitalO]ker4[r4] == 0, 
 -\[ScriptCapitalO]ker4[r4] + \[ScriptCapitalO]ker4[rprp] == 0, 
 \[ScriptCapitalO]ker4[r3p] - \[ScriptCapitalO]ker4[r4] == 0}
