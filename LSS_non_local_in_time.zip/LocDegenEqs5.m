(* Created with the Wolfram Language : www.wolfram.com *)
{(-80*\[ScriptCapitalO]ker5[rp3])/147 + (8*\[ScriptCapitalO]ker5[rprp])/21 - 
   (16*\[ScriptCapitalO]ker5[rp2*\[Delta]])/49 + 
   \[ScriptCapitalO]ker5[\[Delta]^2] - 
   (32*\[ScriptCapitalO]ker5[r3*\[Theta]])/147 + 
   (16*\[ScriptCapitalO]ker5[rp2*\[Theta]])/21 - 
   2*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]] + 
   (8*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]])/21 + 
   \[ScriptCapitalO]ker5[\[Theta]^2] - 
   (8*\[ScriptCapitalO]ker5[rp*\[Theta]^2])/21 - 
   (8*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/147 == 0, 
 (-8*\[ScriptCapitalO]ker5[r3*\[Delta]^2])/21 + \[ScriptCapitalO]ker5[
    \[Delta]^3] + (8*\[ScriptCapitalO]ker5[\[Delta]^5])/21 + 
   (6*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]])/7 - 
   (10*\[ScriptCapitalO]ker5[r2*\[Theta]^2])/7 + 
   (10*\[ScriptCapitalO]ker5[rp*\[Theta]^2])/7 - 
   \[ScriptCapitalO]ker5[\[Theta]^3] - 
   (16*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/7 + 
   (10*\[ScriptCapitalO]ker5[\[Theta]^4])/7 == 0, 
 (-16*\[ScriptCapitalO]ker5[r3*\[Delta]^2])/63 + 
   (16*\[ScriptCapitalO]ker5[\[Delta]^5])/63 + 
   (2*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]])/7 + 
   \[ScriptCapitalO]ker5[\[Delta]^2*\[Theta]] - 
   (20*\[ScriptCapitalO]ker5[r2*\[Theta]^2])/21 + 
   (26*\[ScriptCapitalO]ker5[rp*\[Theta]^2])/21 - 
   \[ScriptCapitalO]ker5[\[Theta]^3] - 
   (26*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/21 + 
   (2*\[ScriptCapitalO]ker5[\[Theta]^4])/3 == 0, 
 (-8*\[ScriptCapitalO]ker5[r3*\[Delta]^2])/63 + 
   (8*\[ScriptCapitalO]ker5[\[Delta]^5])/63 - 
   (10*\[ScriptCapitalO]ker5[r2*\[Theta]^2])/21 + 
   (16*\[ScriptCapitalO]ker5[rp*\[Theta]^2])/21 + 
   \[ScriptCapitalO]ker5[\[Delta]*\[Theta]^2] - \[ScriptCapitalO]ker5[
    \[Theta]^3] - (10*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/21 + 
   (4*\[ScriptCapitalO]ker5[\[Theta]^4])/21 == 0, 
 -\[ScriptCapitalO]ker5[p3] - 3*\[ScriptCapitalO]ker5[r2p] + 
   \[ScriptCapitalO]ker5[r3] + 3*\[ScriptCapitalO]ker5[rp2] == 0, 
 (8*\[ScriptCapitalO]ker5[rp3])/21 + (4*\[ScriptCapitalO]ker5[rprp])/21 + 
   \[ScriptCapitalO]ker5[r2*\[Delta]] + 
   (4*\[ScriptCapitalO]ker5[rp2*\[Delta]])/21 - 
   (8*\[ScriptCapitalO]ker5[r3*\[Delta]^2])/63 + 
   (8*\[ScriptCapitalO]ker5[\[Delta]^5])/63 - \[ScriptCapitalO]ker5[
    r2*\[Theta]] - (20*\[ScriptCapitalO]ker5[rp2*\[Theta]])/21 - 
   (2*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]])/21 - 
   (10*\[ScriptCapitalO]ker5[r2*\[Theta]^2])/21 + 
   (6*\[ScriptCapitalO]ker5[rp*\[Theta]^2])/7 - 
   (4*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/7 + 
   (10*\[ScriptCapitalO]ker5[\[Theta]^4])/21 == 0, 
 (20*\[ScriptCapitalO]ker5[rp3])/21 - (8*\[ScriptCapitalO]ker5[rprp])/21 + 
   \[ScriptCapitalO]ker5[rp*\[Delta]] + 
   (8*\[ScriptCapitalO]ker5[rp2*\[Delta]])/21 - 
   (8*\[ScriptCapitalO]ker5[r3*\[Delta]^2])/63 + 
   (8*\[ScriptCapitalO]ker5[\[Delta]^5])/63 + 
   (2*\[ScriptCapitalO]ker5[r3*\[Theta]])/7 - \[ScriptCapitalO]ker5[
    rp*\[Theta]] - (10*\[ScriptCapitalO]ker5[rp2*\[Theta]])/7 - 
   (8*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]])/21 - 
   (10*\[ScriptCapitalO]ker5[r2*\[Theta]^2])/21 + 
   (8*\[ScriptCapitalO]ker5[rp*\[Theta]^2])/7 - 
   (10*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/21 + 
   (8*\[ScriptCapitalO]ker5[\[Theta]^4])/21 == 0, 
 (32*\[ScriptCapitalO]ker5[rp3])/21 - (20*\[ScriptCapitalO]ker5[rprp])/21 + 
   \[ScriptCapitalO]ker5[p2*\[Delta]] + 
   (4*\[ScriptCapitalO]ker5[rp2*\[Delta]])/7 - 
   (8*\[ScriptCapitalO]ker5[r3*\[Delta]^2])/63 + 
   (8*\[ScriptCapitalO]ker5[\[Delta]^5])/63 - \[ScriptCapitalO]ker5[
    p2*\[Theta]] + (4*\[ScriptCapitalO]ker5[r3*\[Theta]])/7 - 
   (40*\[ScriptCapitalO]ker5[rp2*\[Theta]])/21 - 
   (2*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]])/3 - 
   (10*\[ScriptCapitalO]ker5[r2*\[Theta]^2])/21 + 
   (10*\[ScriptCapitalO]ker5[rp*\[Theta]^2])/7 - 
   (8*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/21 + 
   (2*\[ScriptCapitalO]ker5[\[Theta]^4])/7 == 0, 
 \[ScriptCapitalO]ker5[\[Delta]^4] - 
   4*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3] + 
   3*\[ScriptCapitalO]ker5[\[Theta]^4] == 0, 
 \[ScriptCapitalO]ker5[r3*\[Delta]] - \[ScriptCapitalO]ker5[rp2*\[Delta]] - 
   \[ScriptCapitalO]ker5[r3*\[Theta]] + \[ScriptCapitalO]ker5[
    rp2*\[Theta]] == 0, \[ScriptCapitalO]ker5[r2*\[Delta]^2] - 
   2*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]] - 
   \[ScriptCapitalO]ker5[r2*\[Theta]^2] + 
   2*\[ScriptCapitalO]ker5[rp*\[Theta]^2] == 0, 
 \[ScriptCapitalO]ker5[r2^2] + 4*\[ScriptCapitalO]ker5[rp3] - 
   6*\[ScriptCapitalO]ker5[rprp] + (8*\[ScriptCapitalO]ker5[rp2*\[Delta]])/
    3 + (8*\[ScriptCapitalO]ker5[r3*\[Theta]])/3 - 
   (8*\[ScriptCapitalO]ker5[rp2*\[Theta]])/3 - 
   4*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]] - 
   2*\[ScriptCapitalO]ker5[r2*\[Theta]^2] + 
   4*\[ScriptCapitalO]ker5[rp*\[Theta]^2] + 
   (4*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/3 - 
   \[ScriptCapitalO]ker5[\[Theta]^4] == 0, 
 \[ScriptCapitalO]ker5[r4] + 2*\[ScriptCapitalO]ker5[rp3] - 
   3*\[ScriptCapitalO]ker5[rprp] == 0, 
 \[ScriptCapitalO]ker5[p2^2] - 4*\[ScriptCapitalO]ker5[rp3] + 
   2*\[ScriptCapitalO]ker5[rprp] - (4*\[ScriptCapitalO]ker5[r3*\[Theta]])/3 + 
   4*\[ScriptCapitalO]ker5[rp2*\[Theta]] + 
   2*\[ScriptCapitalO]ker5[r2*\[Theta]^2] - 
   4*\[ScriptCapitalO]ker5[rp*\[Theta]^2] + \[ScriptCapitalO]ker5[\[Theta]^4]/
    3 == 0, \[ScriptCapitalO]ker5[p4] - 2*\[ScriptCapitalO]ker5[rp3] + 
   \[ScriptCapitalO]ker5[rprp] == 0, 
 \[ScriptCapitalO]ker5[p2*r2] - 2*\[ScriptCapitalO]ker5[rprp] + 
   (4*\[ScriptCapitalO]ker5[rp2*\[Delta]])/3 + 
   (2*\[ScriptCapitalO]ker5[r3*\[Theta]])/3 + 
   (2*\[ScriptCapitalO]ker5[rp2*\[Theta]])/3 - 
   2*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]] + 
   (2*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/3 - 
   \[ScriptCapitalO]ker5[\[Theta]^4]/3 == 0, 
 \[ScriptCapitalO]ker5[r2p2] - \[ScriptCapitalO]ker5[rprp] == 0, 
 \[ScriptCapitalO]ker5[r2*r3] + (7*\[ScriptCapitalO]ker5[rp2*\[Delta]])/2 - 
   \[ScriptCapitalO]ker5[r3*\[Delta]^2] - 
   (7*\[ScriptCapitalO]ker5[rp2*\[Theta]])/2 == 0, 
 \[ScriptCapitalO]ker5[r3p] + \[ScriptCapitalO]ker5[rp3] - 
   2*\[ScriptCapitalO]ker5[rprp] == 0, 
 \[ScriptCapitalO]ker5[r5] + (35*\[ScriptCapitalO]ker5[rp2*\[Delta]])/12 - 
   (5*\[ScriptCapitalO]ker5[r3*\[Delta]^2])/3 + 
   (2*\[ScriptCapitalO]ker5[\[Delta]^5])/3 - 
   (35*\[ScriptCapitalO]ker5[rp2*\[Theta]])/12 - 
   (35*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/12 + 
   (35*\[ScriptCapitalO]ker5[\[Theta]^4])/12 == 0, 
 \[ScriptCapitalO]ker5[p2*rp] - 2*\[ScriptCapitalO]ker5[rp3] + 
   (2*\[ScriptCapitalO]ker5[rp2*\[Delta]])/3 - 
   \[ScriptCapitalO]ker5[r3*\[Theta]]/3 + 
   (7*\[ScriptCapitalO]ker5[rp2*\[Theta]])/3 - \[ScriptCapitalO]ker5[
    rp*\[Delta]*\[Theta]] + \[ScriptCapitalO]ker5[r2*\[Theta]^2] - 
   2*\[ScriptCapitalO]ker5[rp*\[Theta]^2] + 
   \[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3]/3 == 0, 
 \[ScriptCapitalO]ker5[r2*rp] + 2*\[ScriptCapitalO]ker5[rp3] - 
   4*\[ScriptCapitalO]ker5[rprp] + 2*\[ScriptCapitalO]ker5[rp2*\[Delta]] + 
   (5*\[ScriptCapitalO]ker5[r3*\[Theta]])/3 - \[ScriptCapitalO]ker5[
    rp2*\[Theta]] - 3*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]] - 
   \[ScriptCapitalO]ker5[r2*\[Theta]^2] + 
   2*\[ScriptCapitalO]ker5[rp*\[Theta]^2] + \[ScriptCapitalO]ker5[
    \[Delta]*\[Theta]^3] - (2*\[ScriptCapitalO]ker5[\[Theta]^4])/3 == 0, 
 \[ScriptCapitalO]ker5[rp^2] - 2*\[ScriptCapitalO]ker5[rprp] + 
   (4*\[ScriptCapitalO]ker5[rp2*\[Delta]])/3 + 
   (2*\[ScriptCapitalO]ker5[r3*\[Theta]])/3 + 
   (2*\[ScriptCapitalO]ker5[rp2*\[Theta]])/3 - 
   2*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]] + 
   (2*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/3 - 
   \[ScriptCapitalO]ker5[\[Theta]^4]/3 == 0, 
 \[ScriptCapitalO]ker5[p3*\[Delta]] - \[ScriptCapitalO]ker5[rp2*\[Delta]] + 
   \[ScriptCapitalO]ker5[r3*\[Theta]]/2 - \[ScriptCapitalO]ker5[rp2*\[Theta]]/
    2 == 0, \[ScriptCapitalO]ker5[r2^2*\[Delta]] - 
   \[ScriptCapitalO]ker5[\[Delta]^5] + 
   (7*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]])/2 - 
   (7*\[ScriptCapitalO]ker5[rp*\[Theta]^2])/2 + 
   (7*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/2 - 
   (7*\[ScriptCapitalO]ker5[\[Theta]^4])/2 == 0, 
 \[ScriptCapitalO]ker5[r2p*\[Delta]] - \[ScriptCapitalO]ker5[rp2*\[Delta]] - 
   \[ScriptCapitalO]ker5[r3*\[Theta]]/2 + \[ScriptCapitalO]ker5[rp2*\[Theta]]/
    2 == 0, \[ScriptCapitalO]ker5[r4*\[Delta]] - 
   (4*\[ScriptCapitalO]ker5[r3*\[Delta]^2])/3 + 
   \[ScriptCapitalO]ker5[\[Delta]^5]/3 + 
   (7*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]])/4 - 
   (7*\[ScriptCapitalO]ker5[rp*\[Theta]^2])/4 - 
   (7*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/4 + 
   (7*\[ScriptCapitalO]ker5[\[Theta]^4])/4 == 0, 
 \[ScriptCapitalO]ker5[p2*\[Delta]^2] - 
   2*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]] + 
   \[ScriptCapitalO]ker5[r2*\[Theta]^2] == 0, 
 \[ScriptCapitalO]ker5[rp*\[Delta]^2] - 
   2*\[ScriptCapitalO]ker5[rp*\[Delta]*\[Theta]] + 
   \[ScriptCapitalO]ker5[rp*\[Theta]^2] == 0, 
 \[ScriptCapitalO]ker5[r2*\[Delta]^3] - \[ScriptCapitalO]ker5[\[Delta]^5] + 
   (7*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3])/2 - 
   (7*\[ScriptCapitalO]ker5[\[Theta]^4])/2 == 0, 
 \[ScriptCapitalO]ker5[p3*\[Theta]] + \[ScriptCapitalO]ker5[r3*\[Theta]]/2 - 
   (3*\[ScriptCapitalO]ker5[rp2*\[Theta]])/2 == 0, 
 \[ScriptCapitalO]ker5[r2p*\[Theta]] - \[ScriptCapitalO]ker5[r3*\[Theta]]/2 - 
   \[ScriptCapitalO]ker5[rp2*\[Theta]]/2 == 0, 
 \[ScriptCapitalO]ker5[p2*\[Delta]*\[Theta]] - \[ScriptCapitalO]ker5[
    rp*\[Delta]*\[Theta]] + \[ScriptCapitalO]ker5[r2*\[Theta]^2] - 
   \[ScriptCapitalO]ker5[rp*\[Theta]^2] == 0, 
 \[ScriptCapitalO]ker5[r2*\[Delta]*\[Theta]] - \[ScriptCapitalO]ker5[
    rp*\[Delta]*\[Theta]] - \[ScriptCapitalO]ker5[r2*\[Theta]^2] + 
   \[ScriptCapitalO]ker5[rp*\[Theta]^2] == 0, 
 \[ScriptCapitalO]ker5[\[Delta]^3*\[Theta]] - 
   3*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3] + 
   2*\[ScriptCapitalO]ker5[\[Theta]^4] == 0, 
 \[ScriptCapitalO]ker5[p2*\[Theta]^2] + \[ScriptCapitalO]ker5[
    r2*\[Theta]^2] - 2*\[ScriptCapitalO]ker5[rp*\[Theta]^2] == 0, 
 \[ScriptCapitalO]ker5[\[Delta]^2*\[Theta]^2] - 
   2*\[ScriptCapitalO]ker5[\[Delta]*\[Theta]^3] + 
   \[ScriptCapitalO]ker5[\[Theta]^4] == 0}
